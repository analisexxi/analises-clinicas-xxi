
ANALISES_CLINICAS_XXI - Package
----------------------------------

Conteúdo do pacote:
- index.html
- css/style.css
- js/lang.js
- images/logo.png
- README.txt

Como visualizar localmente:
1. Extraia o ficheiro ZIP para uma pasta no teu computador.
2. Abra o ficheiro 'index.html' com um navegador moderno (Chrome, Edge, Firefox).

Editar conteúdo:
- Para editar textos, abre 'index.html' num editor de texto (ex: VS Code).
- As strings traduzíveis estão marcadas com o atributo data-i18n no HTML e podem ser alteradas no ficheiro js/lang.js.
- Estilos estão em css/style.css.
- Logo em images/logo.png.

Publicar online (opções rápidas):
- GitHub Pages: cria um repositório e faz upload dos ficheiros; nas definições (Settings) ativa Pages apontando para a branch principal.
- Netlify: arrasta e solta a pasta (ou o index.html) no painel do Netlify para publicar.
- Vercel: criar um novo projeto a partir da pasta estática.

Contactos incluídos (modificáveis):
Email: analisexxi@gmail.com
WhatsApp: +244 951 716 182
Facebook: https://facebook.com/analisexxi
Instagram: https://instagram.com/analisexxi

Licença:
Este template foi criado para o projeto 'Análises Clínicas XXI' e pode ser adaptado livremente pelos autores.
