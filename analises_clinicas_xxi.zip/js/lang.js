
const strings = {
  pt: {
    'nav.home':'Início',
    'nav.articles':'Artigos',
    'nav.about':'Sobre',
    'nav.contacts':'Contactos',
    'hero.title':'Análises Clínicas XXI',
    'hero.subtitle':'Ciência, Diagnóstico e Inovação',
    'hero.lead':'Espaço educativo criado por Ernesto T. Miguel, Vuvu A. S. Mpovi e Elisa F. K. Tchimano. Encontre artigos, guias e recursos práticos para estudantes e profissionais.',
    'hero.cta':'Ler artigos',
    'a1.title':'O que são Análises Clínicas?',
    'a1.excerpt':'Introdução às áreas: hematologia, bioquímica, microbiologia e imunologia.',
    'a1.read':'Ler artigo',
    'a2.title':'Provas laboratoriais essenciais',
    'a2.excerpt':'Glicémia, hemograma completo, perfil lipídico e função hepática — interpretação básica.',
    'a2.read':'Ler artigo',
    'a3.title':'Ética e boas práticas no laboratório',
    'a3.excerpt':'Normas, controlo de qualidade e segurança do paciente.',
    'a3.read':'Ler artigo',
    'about.title':'Sobre os autores',
    'about.e1':'Professor de Física, Biologia e Química. Estudante do 4.º ano em Análises Clínicas. Autor principal.',
    'about.e2':'Coautora com experiência em metodologias de investigação científica.',
    'about.e3':'Técnica de laboratório e coautora, com foco em práticas laboratoriais.',
    'contacts.title':'Contactos',
    'contacts.desc':'Envia-nos mensagens ou propostas de colaboração.'
  },
  en: {
    'nav.home':'Home',
    'nav.articles':'Articles',
    'nav.about':'About',
    'nav.contacts':'Contacts',
    'hero.title':'Clinical Analysis XXI',
    'hero.subtitle':'Science, Diagnosis and Innovation',
    'hero.lead':'Educational space created by Ernesto T. Miguel, Vuvu A. S. Mpovi and Elisa F. K. Tchimano. Find articles, guides and practical resources for students and professionals.',
    'hero.cta':'Read articles',
    'a1.title':'What are Clinical Analyses?',
    'a1.excerpt':'Introduction to areas: hematology, clinical biochemistry, microbiology and immunology.',
    'a1.read':'Read article',
    'a2.title':'Essential laboratory tests',
    'a2.excerpt':'Glycemia, complete blood count, lipid profile and liver function — basic interpretation.',
    'a2.read':'Read article',
    'a3.title':'Ethics and good laboratory practices',
    'a3.excerpt':'Standards, quality control and patient safety.',
    'a3.read':'Read article',
    'about.title':'About the authors',
    'about.e1':'Teacher of Physics, Biology and Chemistry. 4th year Clinical Analysis student. Lead author.',
    'about.e2':'Co-author experienced in research methodologies.',
    'about.e3':'Laboratory technician and co-author, focused on laboratory practices.',
    'contacts.title':'Contacts',
    'contacts.desc':'Send us messages or collaboration proposals.'
  }
};

function setLanguage(lang){
  document.documentElement.lang = (lang === 'pt') ? 'pt' : 'en';
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if(strings[lang] && strings[lang][key]){
      el.textContent = strings[lang][key];
    }
  });
  // toggle button text
  const btn = document.getElementById('lang-toggle');
  btn.textContent = lang === 'pt' ? 'EN' : 'PT';
  localStorage.setItem('site_lang', lang);
}

document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('site_lang') || 'pt';
  setLanguage(saved);

  document.getElementById('lang-toggle').addEventListener('click', () => {
    const current = (localStorage.getItem('site_lang') || 'pt');
    const next = current === 'pt' ? 'en' : 'pt';
    setLanguage(next);
  });
});
